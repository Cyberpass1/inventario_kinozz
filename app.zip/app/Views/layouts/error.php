<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Error</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="<?= e(asset_url('img/Logo_System.png')) ?>">
    <link rel="stylesheet" href="<?= e(asset_url('css/app.css')) ?>">
</head>
<body class="guest-body">
    <div class="container" style="padding-top:3rem;max-width:700px;"><?= $content ?></div>
</body>
</html>
