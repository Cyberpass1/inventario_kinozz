<?php
declare(strict_types=1);

namespace App\Core\Exceptions;

use Exception;

class HttpException extends Exception {}
